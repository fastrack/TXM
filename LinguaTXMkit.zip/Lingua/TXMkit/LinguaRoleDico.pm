package Lingua::TXMkit::LinguaRoleDico ;

####-----------------------------------
# $Source: LinguaRoleDico.pm $
#$Author	: Ch.Minc $
#$date          : 13/07/2012 21:40:36  $
### Purpose	: Role pour les dicos
### Version	: 1.0
### copyright GNU license
####-----------------------------------

use  5.012003;

use strict ;
#use Carp ;
use Data::Dumper;
use Encode ;

use Moose::Role;

our ($VERSION) = '$Revision: 1.0 $' =~ m{ \$Revision: \s+ (\S+) }xms;

has 'tagged_lines'=>(is=>'rw',
                    isa=>'ArrayRef[Str]',
                    lazy=>1,
                    trigger=>\&_tinydicofilter,
                    default=>sub {[]}
                    );
has 'filterwords'=>(is=>'rw',
                    isa=>'ArrayRef[Str]',
                    lazy=>1,
                    default=>sub {[]}
                    ) ;

# liste des étiquettes de treetagger
my @TTtext = <<'End_Lines' =~ m/(\S.*?)\s+.*\S/g;
ABR Abreviation
ADJ Adjectif
ADV Adverbe
DET:ART Article
DET:POS Pronom Possessif (ma, ta, ...)
INT Interjection
KON Conjunction
NAM Nom Propre
NOM Nom
NUM Numéral
PRO Pronom
PRO:DEM Pronom Démonstratif
PRO:IND Pronom Indefini
PRO:PER Pronom Personnel
PRO:POS Pronom Possessif (mien, tien, ...)
PRO:REL Pronom Relatif
PRP Préposition
PRP:det Préposition + Article (au,du,aux,des)
PUN Ponctuation
PUN:cit Ponctuation de citation
SENT Balise de phrase
SYM Symbole
VER:cond Verbe au conditionnel
VER:futu Verbe au futur
VER:impe Verbe à l’impératif
VER:impf Verbe à l’imparfait
VER:infi Verbe à infinitif
VER:pper Verbe au participe passé
VER:ppre Verbe au participe présent
VER:pres Verbe au présent
VER:simp Verbe au passé simple
VER:subi Verbe à l’imparfait du subjunctif
VER:subp Verbe au présent du subjunctif
End_Lines


sub prolex2txm{
my $pos=shift ;

my %code=('adjective'=>'ADJ','noun'=>'NAM','verbe'=>'VER:INFI','not_found'=> '?');
return $code{$pos} ;
}

sub delaf2txm{
    
my $posp=shift // "xxxx" ;
my $tense=shift // "";
my $person=shift // "";
my $number=shift // "";

my @verb_tense=qw/cond imp gerondif ind inf ppast subj/;
my @gender=qw/feminine masculine/;
my @number=qw/singular plural/ ;

my %delaf2TT = <<'End_Lines' =~ m/(\S.*?)\s+(.*?)\s+.*\n/g;
prep    PRP Préposition
verb    VER: verbe
adverb  ADV   adverbe
prepdet PRP:det preposition conctractée
GN      NOM group de nom
XI      NOM  inconnu
PRON    PRO  Pronom
X       NOM  inconnu
noun    NOM  inconnu
preppro PRO:REL Pronom Relatif (duquel,auquel)
nominaldet  NOM     (ex:automobile de)
det     ?   (nombre cent , aucun, ce ?)
conjs   KON   ( meme,cependant ?)
prepadj PRP Préposition
adj     ADJ     Adjectif
GNPX    NOM group de nom
pronoun PRO     Pronom  (plusieurs ?)
conjc   KON Conjunction
PCDN3   ?   inconnu
intj    INT     Interjection
prefix  ?  prefix
cond    VER:cond Verbe au conditionnel
imp     VER:impe Verbe à l’impératif
gerondif    VER:ppre Verbe au participe présent
ind     VER:?   Verbe à l'indicatif
inf VER:infi Verbe à infinitif
ppast   VER:pper Verbe au participe passé
subj    VER:subp|subi Verbe au présent|l’imparfait  du subjunctif
End_Lines

if($posp =~/^verb$/){
return $delaf2TT{$tense} ;
}
return $delaf2TT{$posp} // "notfound : $posp";
}

sub tlf2txm{
# tags convert from tlf to TT

        my $tlf_code=shift ;
        
	# correspondance .tlf_ccode
	# si word  eq "not_found" means that NAM is probably correct
        # the  visited site does'nt give the tense of the verb so it's set to infinitive in any case
	my %code=('adj'=>'ADJ','adv'=> 'ADV','art'=>'DET:ART','subst.'=>'NOM','verbe'=>'VER:INFI','not_found'=>'NAM');
	my $ttcode ;
	for my $c (keys %code){
		$ttcode=$code{$c};
		last if  ($tlf_code  =~/$c/) ;}
		return $ttcode ;
}

sub _tinydicofilter{
	
# filtre les lignes de mots annotées par TT (tagged_lines) et retourne
# un pointer d'array (filterwords) contenant la forme
# la condition de filtrage :    
#if ($lemme eq '<unknown' || $lexicon ne 'f' || partofs eq 'NAM') ;

my ($self,$new,$old)=@_ ;    

for (@{$self->tagged_lines}){    
    my ($form,$partofs,$lemme,$lexicon,@formslist)=split /\s+/ , decode_utf8 $_;

    # elimination des doublons et filtrage
    unless ($form ~~@{$self->filterwords}){
    push @{$self->filterwords}, $form
        if ($lemme eq '<unknown' || $lexicon ne 'f' ||$partofs eq 'NAM') ; 
    }
}
return ;
}
1;