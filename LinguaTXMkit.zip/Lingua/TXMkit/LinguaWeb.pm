package Lingua::TXMkit::LinguaWeb ;

####-----------------------------------
# $Source: LinguaWeb.pm$
#$Author	: Ch.Minc $
#$date          : 13/07/2012 21:40:36  $
### Purpose	: robot d'acces web url atilf
### Version	: 1.0
### copyright GNU license
####-----------------------------------

use  5.012003;

use strict ;
#use Carp ;
use Moose;
use Web::Scraper ;
use URI ;
use Encode ;

our ($VERSION) = '$Revision: 1.0 $' =~ m{ \$Revision: \s+ (\S+) }xms;

has 'look'=>(is =>'rw',
             isa =>'ArrayRef',
             default=>sub{["title",".tlf_cmot" ,".tlf_ccode" ]});
has 'uri' =>(is =>'rw',
             isa=>'Str',
             default=>"http://www.cnrtl.fr/lexicographie" ) ;

# the word we are looking for
has 'search' =>(is=>'rw',
                  isa=>'Str',
                  trigger=>\&_lookatweb
                  );
has 'h'=>(is=>'rw',
          isa=>'HashRef',
          lazy=>1,
          default=>sub{{}},
         );

sub _lookatweb {
# get a word and retrieve on the following site 
# lemma ( tlf_cmot) , tags(.tlf_ccode),
# default is set to 'not_found'
#synopsis :
#my $uriv="http://www.cnrtl.fr/lexicographie/$u/substantif" ;	

my ($self,$new,$old)=@_ ;  
my $h ;
my $hh ;

for (@{$self->look}) {
my $s=scraper {
	process $_,word =>'TEXT' ;
	result 'word';
} ;

my $uriv=$self->uri . '/'. $new ;
my $uri=URI->new($uriv) ;
$hh->{$_}=encode_utf8($s->scrape($uri) // 'not_found');
}
# a small cleaning (sometimes index and comma  are attached at the end)
$self->h->{'lemme'}=lc $hh->{$self->look->[1]} ;
$self->h->{'lemme'} =~ s/([^a-z_])//g ;
$self->h->{'pos'}=$hh->{$self->look->[2]} ;

}

#===============================================================================
# Standard Moose cleanup.
#===============================================================================

no Moose;
__PACKAGE__->meta->make_immutable;

__END__
    