package Lingua::TXMkit::LinguaWrap ;

####-----------------------------------
# $Source: LinguaWrap.pm $
#$Author	: Ch.Minc $
#$date          : 13/07/2012 21:40:36  $
### Purpose	:  wrap roles for Lingua
### Version	: 1.0
### copyright GNU license
####-----------------------------------

use  5.012003;
use strict ;
use warnings ;

use Encode ;

use MongoDB ;

use Moose;
with 'Lingua::TXMkit::LinguaRoleTT','Lingua::TXMkit::LinguaRoleDico','Lingua::TXMkit::LinguaRoleFlemm' ;

#use Lingua::TXMkit::LinguaWeb ;
#use Lingua::TXMkit::LinguaWeblx3 ;
use LinguaDico ;
use LinguaDicoDelaf ;
use LinguaWeb ;
use LinguaWeblx3 ;

our ($VERSION) = '$Revision: 1.0 $' =~ m{ \$Revision: \s+ (\S+) }xms;

sub consult {

my $self=shift ;

my $conn= MongoDB::Connection->new;
my $db = $conn->dicos;

# consult Prolex et Delaf
my $chk2Prolex=Lingua::TXMkit::LinguaDico->new() ;
$chk2Prolex->dbase($db) ;

my $chk2Delaf=Lingua::TXMkit::LinguaDicoDelaf->new() ;
$chk2Delaf->dbase($db) ;

# generation du fichier "lex"

my @lexstring ;

for my $var ( @{$self->filterwords} ){
    
    my $varu=lc decode_utf8 ($var) ;
    #~ $chk2Prolex->search($varu);
    #~ my $resu=$chk2Prolex->lookatdico() ;
    $chk2Prolex->search($varu);
# requete sur Dico Prolex    
    if($chk2Prolex->h->{count} > 0) {
        my $string=$var ;
        for (0..($chk2Prolex->h->{count}-1)){
            my $ptt=&prolex2txm($chk2Prolex->h->{'pos'}[$_]) ;
            $string .="\t" . "$ptt" . "\t" . $chk2Prolex->h->{'lemme'}->[$_];            
        }
        push @lexstring ,$string  ;
	# pour l'ecriture du fichier lexical (extension = lex )

	# necessaire de ne pas avoir de crlf à la fin !
	#my $lexstring=
	return join "\n", @lexstring ;
    }
# requete sur Dico Delaf    
    else{
        #~ $chk2Delaf->search($varu);
        #~ $resu=$chk2Delaf->lookatdico() ;
	$chk2Delaf->search($varu);
    
    if($chk2Delaf->h->{count} > 0) {
        my $string=$var ;
        for (0..($chk2Delaf->h->{count}-1)){
            my $r=&delaf2txm($chk2Delaf->h->{'pos'}[$_], $chk2Delaf->h->{'tense'}[$_]  //  "");  
            $string .="\t" . "$r" . "\t" . $chk2Delaf->h->{'lemme'}[$_]  ;
        }
        push @lexstring , $string ;
	return join "\n", @lexstring ;
    }
    
    }
# on peut ajouter d'autres requetes avec elsif add libitum ...

say "Avertissement, ce mot n'a pas été trouvé dans les dicos : $var" ;

}

=pod Exemples avec des robots

    my $varu="tomba" ; 
    my $scrap=Lingua::TXMkit::LinguaWeb->new(search=>$varu) ;
    say  "$scrap->{h}->{'lemme'} ",decode_utf8 $scrap->{h}->{'pos'} ;
 #   ou   
    $varu=decode_utf8 "épistémologie" ;
    $scrap->search($varu);
    my $webpos=decode_utf8 $scrap->{h}->{'pos'} ;
    say $webpos ;
    say decode_utf8 "$scrap->{h}->{'lemme'} " , ;
    
     $varu=decode_utf8 'desséchées' ;
    
    my $dicolx3=Lingua::TXMkit::LinguaWeblx3->new() ;
    $dicolx3->search($varu) ;
    say $dicolx3->h->{'lemme'} ;
    say $dicolx3->h->{'cgramortho'} ; # pos
    say $dicolx3->h->{infover} ;
    say $dicolx3->h->{'genre'};
    say $dicolx3->h->{'nombre'};
    
=cut
return ;
}

#===============================================================================
# Standard Moose cleanup.
#===============================================================================

#no Moose;
#__PACKAGE__->meta->make_immutable;


__END__