package Lingua::TXMkit::LinguaDico ;

####-----------------------------------
### File	: LinguaDico.pm
### Author	: Ch.Minc
### Purpose	: access to local dico (Prolex)
### Version	: 1.0 11/06/2011 21:40:36
### copyright GNU license
####-----------------------------------

use  5.012003;

use strict ;

use MongoDB;
use MongoDB::OID;
use Moose;
use Carp;

our ($VERSION) = '$Revision: 1.0 $' =~ m{ \$Revision: \s+ (\S+) }xms;


has 'dbase'=>(is =>'rw',isa=>'MongoDB::Database');

has 'collname'=>(is =>'rw',
           isa=>'Str',
           default=>'Prolex') ;

has 'lemmeseq' =>(is=>'rw',
                  isa=>'Str',
                  default=>'LexicalEntry.Lemma.writtenForm');

has 'posseq' =>(is=>'rw',
                  isa=>'Str',
                  default=>'LexicalEntry.partOfSpeech');

has 'formsseq'=>(is=>'rw',
                  isa=>'Str',
                  default=>'LexicalEntry.WordForm.writtenForm');

# the word we are looking for
has 'search' =>(is=>'rw',
                  isa=>'Str',
		  trigger=>\&_lookatdico,
		  );

# the hash containing the results of &_lookatdico		  
has 'h'=>(is=>'rw',
	isa=>'HashRef',
	lazy=>1,
	default=>sub{{}},
		) ;

# here the regex is strict (just this word), could be enlarged : qr/$self->search/i
has 'query'=>(is=>'rw',
                  isa=>'RegexpRef',
                  default=>sub{my $w=shift ; qr/^$w$/i});

 has 'callback' => (
      traits  => ['Code'],
      is      => 'ro',
      isa     => 'CodeRef',
      default => sub{sub{}},
      handles => {
          add_more => 'execute',
      },
  );
 
=head1 synopsis

my $conn=Mongo::Connection->new() ;
my $db=$conn->dicos ,

my $query=LinguaDico->new() ;
$query->dbase($db) ;

$query->search($these_words) ;
say "pos : $h->{'pos'} , lemme: $h->{'lemme'}

=cut

sub _lookatdico {
    my $self=shift ;
    my $new=shift ;
    my $old=shift ;
    
=pod
	my $db=shift ;
	my $forme=shift ; # le mot
#	my $qforme=shift ; # la forme du query
	my $coll=shift ; # le dictionnaire
	my $h=shift ; # les resultats (count, lemmes, pos)
=cut


my $subref=sub {my $par=shift ;my $val=shift ;my $var='$val->' ; $var .="{\'$_\'}" for (split /\./,$par) ; eval $var ; };

my $coll=$self->collname ;
my $dico= $self->dbase->$coll;
my $forme=$self->search ;
my $foundd=$dico->find( {$self->formsseq=> qr/^$forme$/i }) ;
$self->h->{count}=$foundd->count  ;

my $i=0 ;

while(my $val=$foundd->next){
$self->h->{'lemme'}[$i]=$subref->($self->lemmeseq,$val) ;
$self->h->{'pos'}[$i]=$subref->($self->posseq,$val);
#&_moretodo ($self,$h,$val,$i,$forme) ;
$self->add_more($self,$self->h,$val,$i,$forme,$self->h->{'pos'}[$i]) ;
$i++ ;
}
return ;
}

#===============================================================================
# Standard Moose cleanup.
#===============================================================================

no Moose;
__PACKAGE__->meta->make_immutable;

__END__
    