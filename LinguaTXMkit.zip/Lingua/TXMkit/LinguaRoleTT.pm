package Lingua::TXMkit::LinguaRoleTT ;

####-----------------------------------
# $Source: LinguaRoleTT.pm $
#$Author	: Ch.Minc $
#$date          : 13/07/2012 21:40:36  $
### Purpose	: Role pour utiliser TT
### Version	: 1.0
### copyright GNU license
####-----------------------------------

use  5.012003;

use strict ;
use warnings ;

use File::Basename;

use Moose::Role;

use Path::Class;
use File::Temp;
use Carp;

our ($VERSION) = '$Revision: 1.0 $' =~ m{ \$Revision: \s+ (\S+) }xms;

# environnement TXM

has 'txmdir' =>(  
                  is =>'rw',
                  isa       => 'Path::Class::Dir',
                  lazy      => 1,
                  default=>sub{
		    dir('C:/Documents and Settings/Charles/TXM/corpora/maj/txm/MAJ')},
);

has 'fname' , is =>'rw',
              isa =>'Str',
	      lazy=>1,
              default=>'propreounon.xml' ; 
                     
has 'input_file', is =>'rw',
                  isa       => 'Path::Class::File',
                  lazy      => 1,
                  default =>sub {my $self=shift ;
                             file($self->txmdir,$self->fname);
                };
                                    
has 'tmp_file' ,is =>'rw',
                isa =>'Str',
		lazy=>1,
                default =>sub {
		  my $self=shift ;
                    my $fh=File::Temp->new(TEMPLATE=>'LingXXXX',
					   DIR => $self->txmdir. '/TMP',
					   SUFFIX => '.tmp',
					   UNLINK => 1);
                    binmode( $fh, ":encoding(UTF-8)" );
                    my $fname = $fh->filename;} ;
                
# regex txm 0.6, récupère le numero du mot,la forme,le pos,le lemme sur un tag <w>
has 'reg_txm'=>(is=>'ro',
                       isa=>'RegexpRef',
                        default=>
                        sub{qr!<w id=".*" n="(?<num>\d+)".*><txm:form>(?<form>.*)</txm:form><txm:ana resp="#txm" type="#.*pos">(?<pos>.*?)</txm:ana><txm:ana resp="#txm" type="#.*lemma">(?<lemma>.*)</txm:ana></w>! }) ;

# regex txm 0.6 récupère les chemins de treetagger (suppose un meme root pour le /bin et le /lib)
has 'reg_treetagger'=>(is=>'ro',
                       isa=>'RegexpRef',
                        default=>
                        sub{qr!<txm:arg name="model" type="String">(?<tt_path>.*\.par)</txm:arg>!}) ;

# regex txm 0.6 pour reannoter le fichier XML TEI source
has 'reg_anno_txm'=>(is=>'ro',
                       isa=>'RegexpRef',
                       default=>sub{qr!(?<deb><w.*n=")(\d+)(?<form>.*><txm:form>)(.*)(?<pos></txm:form><txm:ana.*>)(.*)(?<lemma></txm:ana><txm:ana.*>)(.*)(?<fin></txm:ana></w>)!;  
                       }
                    );

has 'treetagger_lib_path'=>(is => 'rw'  ,
                            isa=> => 'Path::Class::Dir',
                            lazy      => 1,
                            default=>sub{dir('C:','Textometrie','TreeTagger','lib')}
                            );

has 'treetagger_prog_path'=>(is => 'rw'  ,
                            isa=> => 'Path::Class::Dir',
                            lazy      => 1,
                            default=>
                            sub{dir('C:','Textometrie','TreeTagger','bin')}
               );

has 'prg'  ,
      is        => 'ro',
      isa       => 'Str',
      default   => 'tree-tagger.exe' ;

has 'language'   ,
      is        => 'rw',
      isa       => 'Str',
      required  => 1,
      trigger   => \&_validate_language,
      default =>'fr.par' ;

sub _validate_language {
    my ( $self, $language ) = @_;
    # Die if there's no parameter file for this language.
    croak 'There is no parameter file for language ' . '('. $self->language() .')'
	    if ! -e file($self->treetagger_lib_path,$self->language . '.par');
    my $f=file($self->treetagger_lib_path,$self->language . '.par' );
    $self->{'language' } .='.par' ;
    return;
}

has 'options'  , 
      is        => 'ro',
      isa       => 'ArrayRef[Str]',
      default   => sub { [ qw( -token -lemma ) ] } ;


has '_parameter_file' => (
      is        => 'ro',
      isa       => 'Path::Class::File',
      lazy      => 1,
      default   => sub {
          my $self = shift;
          return file(
              $self->treetagger_lib_path,
              $self->language . '.par'
          );
      }
);

has '_abbreviation_file' => (
      is        => 'ro',
      isa       => 'Path::Class::File',
      lazy      => 1,
      default   => sub {
          my $self = shift;
          return file(
              $self->treetagger_lib_path,
              $self->language() . '-abbreviations'
          );
      }
);
has 'has_been_set'=>(is=>'rw',
		     isa=>'Bool',
		     lazy=>1,
		     default=>0);

# recuperation des parametres de TT dans le(s) fichier(s) XML de TXM
sub get_TTpar {
my $self=shift ;
$self->has_been_set(1) ;
my $l=$self->input_file->slurp ;

# positionne les parametres de treetagger
$l=~$self->reg_treetagger ;
my $tt_path=$+{tt_path} ;
my ($name,$path,$suffix) = fileparse($+{tt_path},'.par');
$self->treetagger_lib_path(dir($path)) ;
$path=~s/lib/bin/ ;
$self->treetagger_prog_path(dir($path)) ;
$self->language($name) ;
return ;
}

# recuperation des tokens à partir du XML de TXM 
sub get_seqw {
    my $self=shift ;
    my $w_sequences ;
    my $l=$self->input_file->slurp ;
    
    # choix de transformer l'apostrophe typographique (non digéré par TT)
    $l=~s/’/'/g ;
    
# decoupe le fichier xml en lignes de <w> ...</w>
    $l=~s/\n//g ;
    $l=join "\n<w ",split '<w',$l ;
#say $l ;
    @{$w_sequences}=split /\n/,$l ;

#genere un fichier temporaire avec les formes    
open(my $fo,'>',$self->tmp_file)  || croak "can't open filename: $!";    
# recuperation de la tokenisation
for (1..$#${w_sequences}){
    $w_sequences->[$_]=onespace($w_sequences->[$_]) ;
    $w_sequences->[$_]=~$self->reg_txm;
#    say "$+{form}\t$+{pos}\t$+{lemma}" ;
    print $fo $+{form},"\n"  ;
}
close $fo || croak "can't close file : $!";
return ;
}

# reannotation des fichiers XML de TXM
sub anno_txm{
    
        my $self=shift ;
        my $w_sequences ;
        my $tokens=shift ; # input parameter
	my $fileout=shift ;

    my $l=$self->input_file->slurp ;
    
# decoupe le fichier xml en lg de <w> ...</w>
    $l=~s/\n//g ;
    $l=join "\n<w ",split '<w',$l ;
#say $l ;
    @{$w_sequences}=split /\n/,$l ;

#genere un fichier avec la reannotation   

# substitution dans les champs forme,pos,lemme
# note $w_sequence[0] correspond au header
for my $iter(1..$#{$w_sequences}){
my $txmregn=$iter ; # en cas de renumerotation ?!
my @tags=split/\t/,$tokens->[$iter-1] ;
my ($txmregform,$txmregpos,$txmreglemma)=@tags ;
my $reg_anno=$self->reg_anno_txm ;
if (scalar @tags == 3) {

    $w_sequences->[$iter]=~s/$reg_anno/$+{deb}$txmregn$+{form}$txmregform$+{pos}$txmregpos$+{lemma}$txmreglemma$+{fin}/ ;
    }
else { # additif pour flemme 2 champs pos
    ($txmregform,$txmregpos,my $txmmultextpos,$txmreglemma)=@tags ;    
my $flemmpos="</txm:ana><txm:ana resp=\"#txm\" type=\"#frmultpos\">$txmmultextpos" ;
   $w_sequences->[$iter]=~s/$reg_anno/$+{deb}$txmregn$+{form}$txmregform$+{pos}$txmregpos$flemmpos$+{lemma}$txmreglemma$+{fin}/ ;
}
}
open(my $fo,'>',$fileout)  || croak "can't open filename: $!";
say $fo @{$w_sequences}  ;
close $fo || croak "can't close file : $!";
return ;

}

sub clean_tmp {
    my $self=shift ;
#    tempdir(CLEANUP=>1) ;
    File::Temp::cleanup();
    return ;
}

# execution de TT avec les options (@command_array)
sub run_treetagger {
    my ( $self,@command_array ) = @_;
    my $todo=file($self->treetagger_prog_path,$self->prg) ;
    $todo .=q{ }. file($self->treetagger_lib_path,$self->language).q{ } ;
    $todo .=join q{ },@command_array ;
    my $command_output_handle;

    # Compose the command string and execute it.
    my $process = open(
        $command_output_handle,
        '-|',$todo
        
    ) || croak "Couldn't fork: $!\n";

    # Get the result and close the command output handle.
    my @tagged_lines = <$command_output_handle>;
    close $command_output_handle || croak "can't close command handle : $!";

    # Wait for the child process to terminate.
    waitpid $process, 0;
    
    return \@tagged_lines;
}



sub onespace {
# cancel duplicated whitespace in a string (xml type)
	my $string=shift ;
	my $reg=qr/\s*([<=>\s]|\".*\")\s*/ ;
	$string=~ s/$reg/$1/g ;
	return $string ;
}
	
    
1;                    
  