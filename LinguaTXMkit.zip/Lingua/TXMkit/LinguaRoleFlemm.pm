package Lingua::TXMkit::LinguaRoleFlemm ;

####-----------------------------------
# $Source: LinguaRoleFlemm.pm $
#$Author	: Ch.Minc $
#$date          : 13/07/2012 21:40:36  $
### Purpose	: Role pour utiliser Flemm
### Version	: 1.0
### copyright GNU license
####-----------------------------------

use  5.012003;

use strict ;
#use Carp ;
use Moose::Role;
use Data::Dumper;
use Encode ;
use Encode qw(from_to) ;

use Flemm;
use Flemm::Result;

our ($VERSION) = '$Revision: 1.0 $' =~ m{ \$Revision: \s+ (\S+) }xms;

my $from='utf8';
my $to='cp1252' ;

has 'tagger' => (is => 'rw',
                 isa=>'Str',
                 default=>"TreeTagger");

has 'Flemm_in' => (is => 'rw',
                 isa => 'ArrayRef[Str]',
                 lazy=>1,
                 trigger =>\&_lemmatise,
                 default=>sub{[]}
                ) ;
has 'Flemm_out' => (is => 'rw',
                 lazy=>1,
                 isa => 'ArrayRef[Str]',
                  default=>sub{[]}
                ) ;
has 'lemm' => (is => 'ro',
               isa => 'Flemm') ;

has 'transcode' =>(is =>'rw',
                 isa =>'HashRef[Str]',
                 lazy_build =>1,
                 );
                 
sub _lemmatise {

my $self=shift ;
my $new=shift ;
my $old=shift ;
        
my @tokens=() ;

# etiquetage type TT (@{$tagged_lineslex})
for (@{$self->Flemm_in}){    
my ($form,$partofs,$lemme,$lexicon,@formslist)=split /\s+/, decode_utf8 $_;
#pour compatibilité avec flemm
push @tokens ,encode_utf8(join '',($form,"\t",$partofs,"\t",$lemme,"\n")) ;
}
    my $lm=Flemm->new("Tagger" => "TreeTagger");

    my $flemm=[] ;
    for my $tokenTT (@tokens){
    decode_utf8 $tokenTT ;
    chomp($tokenTT) ;
    
    # passage en latin
    from_to($tokenTT,$from,$to) ;
     my $res =$lm->lemmatize($tokenTT);
     my $toklatin=$res->getResult ;
     
     #retour en utf8
     from_to($toklatin,$to,$from) ;
     push @{$self->Flemm_out} ,$toklatin ;
    }
}

sub multext {
    my $self=shift ;
    my $aref=shift ;
    my @tokens ;
    my $post ;
    for (@{$aref}){

        my ($forme,$pos,$lemme) ;
        my $p="" ;
        my @chunk=split /\|\|/ ; # solutions multiples
        
        ($forme,$pos,$lemme)=split /\s+/,decode_utf8 $chunk[0] ;
        for(@chunk){
        /\S+(?<posmul>.*)\S+/ ;
        my ($forme,$pos,$lemme)=split /\s+/,$+{posmul} ;
        # $post est le pos tt modifié flem et $posmul le pos multext,
        if($pos =~/:/){
        ($post,my $posmul)=split /:/,$pos ;
        $p .= $p ne "" ? '||'. $posmul: $posmul ;
        }
        else {$p=$self->transcode->{$pos};
              $post=$pos;}
        }
        my $partofs=$p  ;
    push @tokens ,encode_utf8(join '',($forme,"\t",$post,"\t",$partofs,"\t",$lemme,"\n")) ;
    }
# flemm ne traite pas tout , seulement les catégories N,V,A,P,D,Sp+D
return \@tokens ;
}
sub _build_transcode {

my $self=shift ;
# pour convertir par defaut les datas non trancodés par Flemm

# liste des étiquettes multext et de treetagger
my @Multext = <<End_Lines =~ m/(.*)\t(.*?)\s+.*\S/g;
X	ABR Abreviation
A	ADJ Adjectif
R	ADV Adverbe
Da	DET:ART Article
Ds	DET:POS Pronom Possessif (ma, ta, ...)
I	INT Interjection
C	KON Conjunction
Np	NAM Nom Propre
Nc	NOM Nom
M	NUM Numéral
P	PRO Pronom
Pd	PRO:DEM Pronom Démonstratif
Pi	PRO:IND Pronom Indefini
Pp	PRO:PER Pronom Personnel	nonréfléchi
Px	PRO:PER Pronom Personnel	réfléchi 
Ps	PRO:POS Pronom Possessif (mien, tien, ...)
Pr	PRO:REL Pronom Relatif
S	PRP Préposition
?	PRP:det Préposition + Article (au,du,aux,des)
Ys	PUN Ponctuation
Ys	PUN:cit Ponctuation de citation Yso|Ysc
Ysw	SENT Balise de phrase
?	SYM Symbole
V.c	VER:cond Verbe au conditionnel
V..f	VER:futu Verbe au futur
V.fé	VER:impe Verbe à l’impératif
V.ii	VER:impf Verbe à l’imparfait (indicatif)
V.n	VER:infi Verbe à infinitif
V.pa	VER:pper Verbe au participe passé
V.pp	VER:ppre Verbe au participe présent
V.ip	VER:pres Verbe au présent (indicatif)
V.s	VER:simp Verbe au passé simple (indicatif)
V.si	VER:subi Verbe à l’imparfait du subjunctif
V.sp	VER:subp Verbe au présent du subjunctif
End_Lines

my $transcode={} ;
map {$transcode->{$Multext[2*$_+1]}=$Multext[2*$_]} (0..$#Multext/2) ;

return $transcode ;

# for future use
my @I=split /,/,"adieu, ah, ahi, aïe, allo (allô), bah, baste, barnique, bravo, çà, chiche, chut, crac, dame, dia, eh, euh, fi, fichtre, foin, gare, ha, haïe, hardi, hé, hein, hélas, hem, ho, holà, hon, hosanna, hourra, hue, hum, là, las, mince, motus, ô, oh, ohé, ouais, ouf, ouiche, ouste, paf, pan, patatras, pif, pouah, pst, quoi, sacristi, saperlipopette, saperlotte, sapristi, st, sus, vivat, zest, zut, ah ! çà, à la bonne heure, bonté divine, eh bien, eh quoi, fi donc, grand Dieu, hé bien, hé quoi, ho ! ho, jour de Dieu, juste Ciel, là ! là, ma foi, mille bombes, mon Dieu, or çà, or sus, oui-da, par exemple, quoi donc, ta ta ta, tout beau, tout doux" ;

my @px=qw/se s'/ ;

my @S=split /,/,"à, après, attendu, avant, avec, chez, concernant, contre, dans, de, depuis, derrière, dès, devant, durant, en, entre, envers, excepté, hormis, hors, jusque(s), malgré, moyennant, outre, par, parmi, passé, pendant, plein, pour, près, proche, sans, sauf, selon, sous, suivant, supposé, sur, touchant, vers, vu" ;

}
1;