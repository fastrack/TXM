package Lingua::TXMkit::LinguaWeblx3 ;

####-----------------------------------
# $Source: LinguaWeblx3.pm$
#$Author	: Ch.Minc $
#$date          : 13/07/2012 21:40:36  $
### Purpose	: robot d'acces web Lexique3
### Version	: 1.0
### copyright GNU license
####-----------------------------------


use  5.012003;

use strict ;
#use Carp ;

use Moose;
use Web::Scraper ;
use URI ;
use Encode ;
use Encode qw(from_to) ;
my $from='utf8';
my $to='iso-8859-1' ;
use HTML::Entities ;
use URI::Escape ;

our ($VERSION) = '$Revision: 1.0 $' =~ m{ \$Revision: \s+ (\S+) }xms;

has 'look'=>(is =>'rw',
             isa =>'ArrayRef',
             default=>sub{["tr.li" ]});
has 'uri' =>(is =>'rw',
             isa=>'Str',
             default=>"http://www.lexique.org/moteur/simple.php?database=lexique3&mots" ) ;

# the word we are looking for
has 'search' =>(is=>'rw',
                  isa=>'Str',
		  trigger=>\&_lookatweb
                  );
		  
# the hash containing the results of &_lookatdico		  
has 'h'=>(is=>'rw',
	isa=>'HashRef',
	lazy=>1,
	default=>sub{{}},
		) ;		  

sub _lookatweb {

my $self=shift ;


my $s=scraper {
	
	process  "tr.li>td", "list[]" => "TEXT";
	result 'list' ;
} ;

my $find=lc decode_utf8 $self->search ;
$find= uri_escape($find) ;
my $uriv=$self->uri . '='. $find ;
my $uri=URI->new($uriv) ;

my $list=$s->scrape($uri)  if defined($s->scrape($uri));
my @var=qw/ortho phon lemme cgram genre nombre freqlemfilms2 freqlemlivres freqfilms2 freqlivres infover nbhomogr nbhomoph islem nblettres nbphons cvcv p_cvcv voisorth voisphon puorth puphon syll nbsyll cv_cv orthrenv phonrenv orthosyll cgramortho deflem defobs old20 pld20 morphoder nbmorph/ ;

map {$self->h->{$var[$_]}=$list->[$_]} (0..$#var) ;

return  ;
}

#===============================================================================
# Standard Moose cleanup.
#===============================================================================

no Moose;
__PACKAGE__->meta->make_immutable;

__END__
    