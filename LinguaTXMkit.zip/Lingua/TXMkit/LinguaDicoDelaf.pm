package Lingua::TXMkit::LinguaDicoDelaf ;

####-----------------------------------
### File	: LinguaDicoDelaf.pm
### Author	: Ch.Minc
### Purpose	: extend lingua dico
### Version	: 1.1 2011/07/18 
### copyright GNU license
####-----------------------------------

use  5.012003;

use strict ;
#use Carp ;
use Moose;
extends 'Lingua::TXMkit::LinguaDico';


our ($VERSION) = '$Revision: 1.1 $' =~ m{ \$Revision: \s+ (\S+) }xms;
      
has '+collname'=>(is =>'rw',
           isa=>'Str',
           default=>'Delaf') ;

has '+lemmeseq' =>(is=>'rw',
                  isa=>'Str',
                  default=>"entry.lemma.\$t");

has '+posseq' =>(is=>'rw',
                  isa=>'Str',
                  default=>"entry.pos.name");

has '+formsseq'=>(is=>'rw',
                  isa=>'Str',
                  default=>"entry.inflected.form.\$t");


has 'tense'=>(is=>'rw',
                  isa=>'Str',
                  default=>"entry.inflected.feat.[0].value");
has 'person'=>(is=>'rw',
                  isa=>'Str',
                  default=>"entry.inflected'.feat'}[1].value") ;
has 'number'=>(is=>'rw',
                  isa=>'Str',
                  default=>"entry.inflected'.feat'}[2].value") ;

has +'callback' => ( 
  is      => 'ro',
 #isa     => 'CodeRef',
      default => sub { \&_add_more }
  );

sub _add_more{
    my $self=shift ;
    my $h=shift ;
    my $val=shift ;
    my $i=shift ;
    my $forme=shift ;
    my $pos=shift ;
    return if ($pos !~ m/^verb$/) ;
    for  (0..$#{$val->{'entry'}{'inflected'}}){

	if ($val->{'entry'}{'inflected'}[$_]{'form'}{'$t'} =~m/^$forme$/i){
            
            if (ref $val->{'entry'}{'inflected'}[$_]{'feat'} eq 'ARRAY') {
                $h->{'tense'}[$i]=$val->{'entry'}{'inflected'}[$_]{'feat'}[0]{'value'};
                $h->{'personne'}[$i]=$val->{'entry'}{'inflected'}[$_]{'feat'}[1]{'value'} ;
                $h->{'number'}[$i]=$val->{'entry'}{'inflected'}[$_]{'feat'}[2]{'value'};}
            else {
                $h->{'tense'}[$i]=$val->{'entry'}{'inflected'}[$_]{'feat'}{'value'};
                 }
	} ;
    };
}

#===============================================================================
# Standard Moose cleanup.
#===============================================================================

no Moose;
__PACKAGE__->meta->make_immutable;

__END__
    