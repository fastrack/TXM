#!c:/Perl/bin/perl.exe
####-----------------------------------
# $Source: TXMreannotate.pl $
#$Author	: Ch.Minc $
#$date          : 13/07/2012 21:40:36  $
### Purpose	: Script pour retroannoter TXM
### Version	: 1.0
### copyright GNU license
####-----------------------------------


use  5.012003;
use strict ;
use warnings ;
use Carp ;
use English qw( -no_match_vars ) ;

use POSIX qw(strftime);
use Path::Class;
use File::Basename ;
#~ use File::Glob ':globally';
use Encode ;

use Moose;
with 'MooseX::Getopt' ;

# indication de l'implantation des modules en cas de configuration non standard
use lib 'J:/perl/perl/TXM/Lingua/TXMkit' ;

use Lingua::TXMkit::LinguaWrap ;

our ($VERSION) = '$Revision: 1.0 $' =~ m{ \$Revision: \s+ (\S+) }xms;

my $now_iso8601= strftime "%Y-%m-%dT%H:%M:%S+02:00", localtime;
say "program $PROGRAM_NAME starts :", $now_iso8601 ;

my $EMPTY = q{};
my $silent=1 ;

# positionnement de variables par defaut

my $def1='C:/Documents and Settings/Charles/TXM/corpora/maj/txm/MAJ';

has 'txm_dir'  => (is => 'rw', isa => 'Str', required => 0,default =>$def1) ;
has 'working_dir'  => (is => 'rw', isa => 'Str', required => 0,default =>$def1) ;

my $param =main->new_with_options();

# general parameters

my $txm_dir=$param->{txm_dir};
my $working_dir=$param->{working_dir};

# positionne le répertoire cible de TXM

my $exp=Lingua::TXMkit::LinguaWrap->new() ;

my $source=dir("$txm_dir") ;
my $target=dir("$working_dir") ;

say "Sources : $source ";

# cree 3 sous repertoires MULTEXT, REANNO et TMP
my $muldir=$target->subdir( 'MULTEXT') ;
if( -e $muldir ) {say "$muldir already exist !"}
else {mkdir $muldir ;}

my $reanno=$target->subdir( 'REANNO') ;
if( -e $reanno ) {say "$reanno already exist !"}
else {mkdir $reanno ;}

my $tmpdir=$target->subdir( 'TMP') ;
if( -e $tmpdir ) {say "$tmpdir already exist !"}
else {mkdir $tmpdir ;}

# glob sur le directory (corpora)
my @files=glob("'$source'/*.xml");
use open ':encoding(utf8)';

for my $txmfiles (@files ){
say "txm files en cours de traitement : $txmfiles " ;

$exp->fname($txmfiles=~m{.*
            [\\|/]              # separateur \ ou /
            (.*)                # extrait le nom de la file
            $}smx) ;

# recupere les chemins de TreeTagger et la "langue" (une seule fois)
$exp->get_TTpar unless $exp->has_been_set;

# recupere les formes a partir de  TXM XML TEI
unless ($silent) {say 'input file : ',$exp->input_file ;}
$exp->get_seqw ;
my $ftmp=$exp->tmp_file ;
unless ($silent) {say 'output temporary file : ',$ftmp ;}

# execute TT avec options specifiques (format etendu)

# pour win les noms de fichiers doivent etre mis avec '"'
my @opts=(qw(-token -lemma -cap-heuristics -proto),&quote($ftmp));

my $tagged_lines=$exp->run_treetagger(@opts) ;

unless ($silent) {say @{$tagged_lines} ;}

# filtrage des resultats (choix particulier : mots inconnus de dans TT)

$exp->tagged_lines( $tagged_lines) ;

# consultations des dictionnaires locaux ou distants (generation du fichier "lex") 

my @lexstring=$exp->consult ;

open (my $fh,">:encoding(UTF-8)","$tmpdir/tagtag0.lex") or croak "unable to open: $!";
say $fh @lexstring ;
close $fh or croak "unable to close: $!"; 

# execute TT avec option "-lex" (format etendu) 

@opts=() ;
@opts=(qw(-token -lemma -cap-heuristics -proto -lex),&quote("$tmpdir/tagtag0.lex"),&quote($ftmp));

my $tagged_lineslex=$exp->run_treetagger(@opts) ;

unless($silent) {
    for ( @{$tagged_lineslex} ) {print $_ } ;}

# Reannotation vers txm

my @tokens=() ;

# etiquetage type TT
for (@{$tagged_lineslex}){
my ($form,$partofs,$lemme,$lexicon,@formslist)=split /\s+/xms, decode_utf8 $_;

#pour compatibilité avec flemm
push @tokens ,encode_utf8(join $EMPTY,($form,"\t",$partofs,"\t",$lemme,"\n")) ;
}

$exp->anno_txm(\@tokens,file($reanno,basename($txmfiles)) ) ;

# consolidation avec Flemm / Codage Multext

$exp->Flemm_in($tagged_lineslex) ;
my $aref=$exp->Flemm_out ;

unless ($silent) {
    for(0..$#{$aref}) {say  "$_  ",decode_utf8($aref->[$_]) };}

my $mul_tokens=$exp->multext($aref) ;
my $exp2=Lingua::TXMkit::LinguaWrap->new() ;
$exp2->anno_txm($mul_tokens,file($muldir,basename($txmfiles)) ) ;

} # end of loop on txm files

say "program $PROGRAM_NAME stops : ", $now_iso8601 ;

# double quote sur les files et path des commandes windows
sub quote {
    my $string = shift;
    return $OSNAME eq 'MSWin32' ? q{"}.$string.q{"} : q{'}.$string.q{'}
}


#===============================================================================
# Standard Moose cleanup.
#===============================================================================

#no Moose;
#__PACKAGE__->meta->make_immutable;

__END__

=head1 NAME

TXMreannotate.pl - Packages Lingua::TXMkit ()

=head1 VERSION

Version 1.0

=head1 DESCRIPTION

Le développement s'est déroulé sous windows XP, mais un effort particulier a été fait pour essayer d'assurer la portabilité vers d'autres systèmes sans pouvoir asseoir cette garantie, faute de tests sur des machines dédiées.

Ce script est destiné à corriger B<partiellement> les erreurs de notation rencontrées dans un étiqueteur morphosyntaxique, en l'occurrence TreeTagger dans le cas présent.

Le réétiquetage se fait à partir d'un fichier XML produit à partir d'une importation dans TXM 0.6.


=head1 ORGANISATION

Afin de respecter la logique organisationnelle du CPAN, ce package fait/fera partie d'un groupe orienté linguistique "Lingua".

De ce fait, la structure hiérarchique des modules en découle et par exemple le package Linguawrap.pm devra être dans le chemin:

    perl-lib-site-path/Lingua/TXMkit/Linguawrap.pm
    
etc. 


=head1 INSTALLATION

Ce programme requiert principalement Perl 5.12.3 (ou plus) dont le package MOOSE, le logiciel MongoDB (dans le cas d'utilisation des dictionnaires associés à ce logiciel L<http://search.cpan.org/dist/MongoDB/>) et le package FLEMMv3.1.

L'installation usuelle se fait sous $some_path/Perl/site/lib en créant éventuellement le chemin $some_path/Perl/site/lib/Lingua/TXMkit où seront placés les packages (.pm). Le script TXMreannotate.pl
s'utilise comme un programme Perl habituel.
En cas de configuration non standard, il conviendra de positionner le chemin dans l'instruction (ligne 28) use lib 'your_path'.


=head1 SYNOPSIS

L'appel au programme est typiquement le suivant :

    perl.exe TXMreannotate.pl --txmdir  'répertoire du projet txm à traiter'

où l'option txmtdir spécifie le répertoire source choisi pour faire la réannotation et donc contenant les fichiers XML
produits par TXM 0.6.

Les résultats sont stockés sous ce même répertoire dans MULTEXT pour les fichiers retranscrits avec les annotations de ce type et dans REANNO pour les fichiers seulement corrigés. (Le répertoire TMP contient des fichiers temporaires).

Un autre répertoire cible peut être choisi en utilisant l'option --working_dir.



=head1 STRUCTURE


=head2  Principes

Le script principal fait appel à plusieurs packages, globalement répartis en quatre groupes fonctionnels.
Le premier groupe correspond aux fonctionnalités pour interroger divers dictionnaires locaux au format JSON (LinguaDico.pm).
Le second groupe permet l'interrogation de dictionnaires distants, autrement dit sur Internet.
Le troisième groupe facilite le traitement des données avec TreeTagger.
Un quatrième groupe traite les appels au package FLEMM-v3.1. Disponible au départ sur le site L<http://www.cnrtl.fr/outils/flemm/> mais dans lequel nous avons dû faire une mise à jour dans le module Flemm::TreeTagger.

Les requêtes sont le plus possible standardisées sous la forme suivante :

    (création de l'objet)  my $query=moduleXXX->new() ;
    (la recherche proprement dite) my $hash=$query->search($This_word) ;

où le tableau associatif $hash contient les informations récupérables, à savoir au moins le lemme et le pos (dans le cas où les réponses sont multiples, on a alors un "array of hash" (tableau de tableaux associatifs).

Le module LinguaWrap.pm lie l'ensemble de ces groupes syntactiquement et contient par ailleurs la méthode consult dans laquelle s'effectue la résolution des tokens indéterminés de TreeTagger.

Le script TXMreannotate gère les appels aux différentes méthodes disponibles pour atteindre le but fixé.

=head2 Script TXMreannotate.pl

Les différentes opérations suivantes sont donc lancées dans ce script :

=over 4

=item

Récupération des données d'entrée

=item

Lecture des fichiers XML et récupération des informations sur TreeTagger

=item

Récupération des Tokens

=item

Exécution de TT avec l'option "-proto", ce qui permet l'obtention des données d'étiquetage (S<f : found>, S<c : found in lowercase>, S<h : half hyphen word>, S<s : suffix, S<p : pretagging>, S<l : lex>,S< <unknown> >)

=item

consultations des dictionnaires sur un nombre limité de données en vertu des résultats précédents, création d'un fichier correctif.

=item

Réexécution de TT avec l'option "-lex". Mise à jour possible des fichiers XML à ce stade.

=item

Ajout de l'annotation Multext qui complète les formes verbales en particulier. Réannotation des fichiers XML.

=back

=head1 PACKAGES/METHODS

=head2 Package Lingua::TXMkit::LinguaDico.pm

Ce package contient les données d'interrogations pour accéder au dictionnaire local Prolex, contenant des noms propres.

Ce fichier téléchargeable à l'adresse :

L<http://www.cnrtl.fr/lexiques/prolex>

comporte les éléments suivants :

    Nombre de prolexèmes : 54 774
            (4 588 anthroponymes,
             49 789 toponymes,
             175 ergonymes et 222 pragmonymes)

Le fichier d'origine en XML a été traduit en JSON afin de permettre son accès par MongoDB.
La commande suivante, pour un système windows, permet de réaliser son importation :

C<c:/mongodb/bin/mongoimport -d dicos -c Prolex --dbpath G:/Dictionnaires/DBmg G:/Dictionnaires/json/prolex.json>

si la base de données des dictionnaires se trouve, par exemple, dans le répertoire G:/Dictionnaires/DBmg et que les fichiers d'origine sont dans le répertoire C<G:/Dictionnaires/json/>.

Le synopsis d'une requête depuis la création de l'objet se déroule ainsi :

    my $conn= MongoDB::Connection->new;
    my $db = $conn->dicos;

    my $chk2Prolex=Lingua::TXMkit::LinguaDico->new() ;
    $chk2Prolex->dbase($db) ;
    
    # consultation Prolex avec le mot contenu dans $varu
    $chk2Prolex->search($varu);
    my $resu=$chk2Prolex->lookatdico() ;

La méthode lookatdico retourne un pointeur de tableau contenant lemmes et pos.

=head2 LinguaDicoDelaf.pm

Ce dictionnaire de noms est téléchargeable sur le site :

L<http://cental.fltr.ucl.ac.be/projects/delaf/>

Le Dictionnaire DELA fléchi (au format XML et encodé en UTF 8) du français comporte :

=over 8

=item S<683 824 entrées simples pour 102 073 lemmes différents>

=item S<108 436 entrées composées pour 83 604 lemmes différents>

=back

Comme précédemment, nous l'avons transcodé au format JSON.

La procédure d'accès, similaire à la précédente, retourne les données selon les cas (le temps, le mode, le genre et le nombre ...).

=head2 LinguaRoleDico.pm

Ce module permet de transformer les pos retournées par les différentes requêtes dans les dictionnaires selon les termes utilisés par TreeTagger.

=head2 LinguaWeb.pm

C'est le module de base pour interroger le site :

L<http://www.cnrtl.fr/lexicographie>


=head2 LinguaWeblx3.pm

C'est le module de base pour interroger le site Lexique3:

L<http://www.lexique.org/moteur/simple.php?database=lexique3>

=head2 LinguaRoleFlemm.pm

Ce module permet l'utilisation de Flemm3 (L<http://www.cnrtl.fr/outils/flemm/>) afin d'annoter notamment les formes verbales, qui ne sont pas complètement disponibles dans les dictionnaires.

Pour des raisons d'évolution des logiciels, en l'occurrence de Perl, il est souhaitable de remplacer le module/package TreeTagger.pm d'origine par celui que nous avons modifié, afin d'éviter de nombreux messages d'alerte ("warnings").
A noter que ces modules sont codés en 'cp1252', tandis que le reste du projet l'est en 'UTF8'.

En définitive, nous avons complété la partie Multext ( L<http://aune.lpl.univ-aix.fr/projects/multext/LEX/LEX2_3.html> ) afin d'obtenir une solution homogène autant que faire se peut dans le cadre présent.

=head2 LinguaRoleTT.pm

Ce module contient les éléments de récupération des données de TXM 0.6 C<sub get_seqw> et la réannotation C<sub anno_txm>. La routine run_treetagger permet de lancer TreeTagger avec les options choisies et de récupérer un pointeur de tableau contenant les résultats de l'exécution.


=head2 LinguaWrap.pm

Ce module permet de fédérer l'ensemble des packages afin de les rendre facilement accessibles à partir d'un programme principal.

De plus, il contient le sous-programme 'consult' qui sert à générer un premier fichier correctif pour TreeTagger. Le principe est simple, car le taux de réussite de TreeTagger, d'environ
95%, donne à penser que l'effort à fournir est faible. Les améliorations du résultat, a priori, dépendront surtout du type de documents étudié, en relation avec un lexique complémentaire adapté.

Ce sous-programme avec les mots sélectionnés, fait juste une recherche dans un dictionnaire de noms propres (PROLEX) et puis en cas d'échec, interroge le dictionnaire Delaf.

Si un utilisateur souhaite modifier ce programme, celui-ci est facilement compréhensible et accessible.

=cut

=

=head1 AUTHOR

Charles Minc, C<< <charles.minc at wanadoo.fr> >>

=head1 BUGS

Please report any bugs or feature requests to C<bug-TXMreannotate.pl at rt.cpan.org>, or through
the web interface at L<http://rt.cpan.org/NoAuth/ReportBug.html?Queue=TXMreannotate.pl>.  I will be notified, and then you'll
automatically be notified of progress on your bug as I make changes.




=head1 SUPPORT

You can find documentation for this module with the perldoc command.

    perldoc TXMreannotate.pl


You can also look for information at:

=over 4

=item * RT: CPAN's request tracker (report bugs here)

L<http://rt.cpan.org/NoAuth/Bugs.html?Dist=TXMreannotate.pl>

=item * AnnoCPAN: Annotated CPAN documentation

L<http://annocpan.org/dist/TXMreannotate.pl>

=item * CPAN Ratings

L<http://cpanratings.perl.org/d/TXMreannotate.pl>

=item * Search CPAN

L<http://search.cpan.org/dist/TXMreannotate.pl/>

=back


=head1 ACKNOWLEDGEMENTS


=head1 LICENSE AND COPYRIGHT

Copyright 2012 Charles Minc.

This program is free software; you can redistribute it and/or modify it under the terms of either: the GNU General Public License as published by the Free Software Foundation; or the Artistic License.

See http://dev.perl.org/licenses/ for more information.


=cut

1; # End of TXMreannotate.pl

